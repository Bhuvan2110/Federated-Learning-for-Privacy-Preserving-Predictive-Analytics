/// api.dart  —  HTTP client  +  E2E encrypted CSV upload
/// ═══════════════════════════════════════════════════════════════
/// Upload flow:
///   1. initEncryption()  →  GET /api/pubkey  →  load RSA key
///   2. upload(file)      →  encrypt → POST /api/upload/encrypted
///   3. Fallback          →  plain POST /api/upload  if key missing
/// ═══════════════════════════════════════════════════════════════

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../models/models.dart';
import 'encryption_service.dart';

class Api {
  static String _base = 'http://10.0.2.2:8080/api';
  static String get base => _base;

  static void setBase(String url) {
    final u = url.trimRight().replaceAll(RegExp(r'/$'), '');
    _base = u.endsWith('/api') ? u : '$u/api';
  }

  // ── Health check ─────────────────────────────────────────────
  static Future<bool> ping() async {
    try {
      final r = await http
          .get(Uri.parse('$_base/health'))
          .timeout(const Duration(seconds: 5));
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Initialise E2E encryption ────────────────────────────────
  /// Call once after ping() succeeds.
  /// Fetches RSA-2048 public key from /api/pubkey and loads it
  /// into EncryptionService so uploads can be encrypted.
  static Future<bool> initEncryption() async {
    try {
      final r = await http
          .get(Uri.parse('$_base/pubkey'))
          .timeout(const Duration(seconds: 10));
      if (r.statusCode != 200) return false;

      final j = jsonDecode(r.body) as Map<String, dynamic>;
      final pem = j['publicKey'] as String? ?? '';
      if (pem.isEmpty) return false;

      EncryptionService.instance.loadPublicKeyFromPem(pem);
      return true;
    } catch (_) {
      return false;
    }
  }

  // ── CSV upload (E2E encrypted when key is available) ─────────
  static Future<CsvData> upload(File f) async {
    final bytes = await f.readAsBytes();

    if (EncryptionService.instance.isReady) {
      // ── ENCRYPTED PATH ────────────────────────────────────────
      final enc = EncryptionService.instance.encrypt(Uint8List.fromList(bytes));

      final body = jsonEncode({
        'encryptedKey':  enc['encryptedKey'],
        'iv':            enc['iv'],
        'encryptedData': enc['encryptedData'],
        'filename':      f.path.split(Platform.pathSeparator).last,
      });

      final r = await http
          .post(
            Uri.parse('$_base/upload/encrypted'),
            headers: {'Content-Type': 'application/json'},
            body: body,
          )
          .timeout(const Duration(seconds: 60));

      final j = jsonDecode(r.body) as Map<String, dynamic>;
      if (r.statusCode != 200) throw Exception(j['error'] ?? 'Encrypted upload failed');

      final csv = CsvData.fromJson(j);
      csv.isEncrypted = true;
      return csv;
    } else {
      // ── FALLBACK: plain multipart upload ──────────────────────
      final req = http.MultipartRequest('POST', Uri.parse('$_base/upload'));
      req.files.add(http.MultipartFile.fromBytes('csvFile', bytes,
          filename: f.path.split(Platform.pathSeparator).last));

      final s    = await req.send().timeout(const Duration(seconds: 60));
      final body = await s.stream.bytesToString();
      final j    = jsonDecode(body) as Map<String, dynamic>;
      if (s.statusCode != 200) throw Exception(j['error'] ?? 'Upload failed');

      final csv = CsvData.fromJson(j);
      csv.isEncrypted = false;
      return csv;
    }
  }

  // ── Train: Central ───────────────────────────────────────────
  static Future<TrainResult> central({
    required List<Map<String, dynamic>> rows,
    required List<String> headers,
    required int targetIdx,
    required Map<String, String> ftypes,
    int epochs = 100,
    double lr = 0.1,
  }) async {
    final r = await http
        .post(
          Uri.parse('$_base/train/central'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'rows': rows, 'headers': headers,
            'targetColIndex': targetIdx, 'featureTypes': ftypes,
            'epochs': epochs, 'lr': lr,
          }),
        )
        .timeout(const Duration(seconds: 180));
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode != 200) throw Exception(j['error'] ?? 'Training failed');
    return TrainResult.fromJson(j);
  }

  // ── Train: Federated ─────────────────────────────────────────
  static Future<TrainResult> federated({
    required List<Map<String, dynamic>> rows,
    required List<String> headers,
    required int targetIdx,
    required Map<String, String> ftypes,
    int rounds = 25,
    int localEpochs = 5,
    double lr = 0.1,
    int numClients = 5,
  }) async {
    final r = await http
        .post(
          Uri.parse('$_base/train/federated'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'rows': rows, 'headers': headers,
            'targetColIndex': targetIdx, 'featureTypes': ftypes,
            'rounds': rounds, 'localEpochs': localEpochs,
            'lr': lr, 'numClients': numClients,
          }),
        )
        .timeout(const Duration(seconds: 180));
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode != 200) throw Exception(j['error'] ?? 'Training failed');
    return TrainResult.fromJson(j);
  }
}
